# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.2](https://github.com/drivercraft/CrabUSB/compare/usb-if-v0.3.1...usb-if-v0.3.2) - 2025-08-25

### Other

- update Rust toolchain version and enhance logging in USB handling

## [0.3.1](https://github.com/drivercraft/CrabUSB/compare/usb-if-v0.3.0...usb-if-v0.3.1) - 2025-08-12

### Other

- enhance error handling in libusb context and error modules ([#26](https://github.com/drivercraft/CrabUSB/pull/26))

## [0.3.0](https://github.com/drivercraft/CrabUSB/compare/usb-if-v0.2.2...usb-if-v0.3.0) - 2025-08-08

### Other

- Dev uvc ([#17](https://github.com/drivercraft/CrabUSB/pull/17))

## [0.2.2](https://github.com/drivercraft/CrabUSB/compare/usb-if-v0.2.1...usb-if-v0.2.2) - 2025-08-07

### Fixed

- transfer ring

### Other

- Merge branch 'main' of github.com:drivercraft/CrabUSB
- keyboard

## [0.2.1](https://github.com/drivercraft/CrabUSB/compare/usb-if-v0.2.0...usb-if-v0.2.1) - 2025-08-07

### Added

- libusb transfer ok

## [0.2.0](https://github.com/drivercraft/CrabUSB/compare/usb-if-v0.1.0...usb-if-v0.2.0) - 2025-08-05

### Other

- ci ([#11](https://github.com/drivercraft/CrabUSB/pull/11))
