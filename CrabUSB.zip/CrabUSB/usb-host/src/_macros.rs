macro_rules! define_int_type {
    ($name:ident, $id:ty) => {
        #[repr(transparent)]
        #[derive(Default, Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
        pub struct $name(pub $id);

        impl $name {
            pub fn raw(&self) -> $id {
                self.0
            }
        }

        impl From<$id> for $name {
            fn from(val: $id) -> Self {
                Self(val)
            }
        }

        impl From<$name> for $id {
            fn from(val: $name) -> Self {
                val.0
            }
        }

        impl core::fmt::Display for $name {
            fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
                write!(f, "{}", self.0)
            }
        }
    };
}

// Lightweight debug console logger that writes to I/O port 0xE9 (QEMU debugcon).
// This mirrors the kernel's `debugconf!` so early boot messages appear on the console.
#[allow(dead_code)]
pub struct _DebugPort;

impl core::fmt::Write for _DebugPort {
    fn write_str(&mut self, s: &str) -> core::fmt::Result {
        for b in s.as_bytes() {
            unsafe { core::arch::asm!("out dx, al", in("dx") 0xE9u16, in("al") *b) }
        }
        Ok(())
    }
}

macro_rules! debugconf {
    ($($tt:tt)*) => {{
        let mut _port = $crate::_macros::_DebugPort;
        let _ = core::fmt::write(&mut _port, format_args!($($tt)*));
    }};
}
